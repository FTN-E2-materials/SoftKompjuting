clear ; close all; clc

num_iters = 1000;

% Vrednosti alpha sa normalizaciom obele�ja
% alpha = 0.1; % premalo alpha, ne konvergira u 30 iteracija
alpha = 0.5; %20 iteracija
% alpha = 1.7; % ide levo desno
% alpha = 2.1; % alpha je preveliko pa dolazi do divergencije

% Vrednosti alpha bez normalizacije obele�ja
alpha = 0.5;

data = load('LifeExpectancySanitation.csv');

x = data(:, 1:size(data, 2)-1);
noExamples = size(x, 1);
noFeatures = size(x, 2)+1;
% Scale features and set them to zero mean
% fprintf('Normalizing Features ...\n');
[x mu sigma] = featureNormalize(x);
% Add intercept term to X
X = [ones(noExamples, 1) x];

y = data(:, size(data,2));

% pocetno theta sa normalizacijom
% theta = zeros(noFeatures, 1);
% pocetno theta bez normalizacije
theta = [100, 40]';

[theta, J_history, theta_history, converged_it] = gradientDescentMulti(X, y, theta, alpha, num_iters);
theta
converged_it

plotTheConvergenceGraph(J_history);
plotGradientDescentSteps3D(theta_history, J_history, X, y, converged_it, alpha);

