% assumes just one feature x (which can have higher order polynomials)
function [] = plotTheModel2D(x, y, theta, MarkerSize, LineWidth, testData_x, testData_y);

p = length(theta); % number of features
no_examples = length(x); % number of training examples

plot(x, y, 'rx', 'MarkerSize', MarkerSize, 'LineWidth', LineWidth); hold on; % plot the training points
plot(testData_x, testData_y, 'bx');

% display theta in title
title_text = ['\theta = ['];
for i=1:length(theta)
    theta_i_text = num2str(theta(i), '%.1f');
    title_text  = [title_text, theta_i_text];
    if(i < length(theta))
        title_text  = [title_text, '; '];    
    end
end
title_text = [title_text ']']; 
title(title_text, 'FontSize', 18);

% plot the model for 100 points between min(x) and max(x):
if (size(testData_x, 1) > 0)
    min_xx = min(min(x), min(testData_x)); 
    max_xx = max(max(x), max(testData_x));
else
    min_xx = min(x);
    max_xx = max(x);
end
xx = linspace(min_xx, max_xx, 100)';
XX = addHigherOrderFeatures(xx, p-1);
model = XX*theta;
plot(xx, model);
hold off;
end