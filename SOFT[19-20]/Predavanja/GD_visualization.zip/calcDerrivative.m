function [d] = calcDerrivative(X, y, theta)
    no_examples = length(y); % number of training examples
    d = zeros(size(theta));
    
    err = X*theta-y;
    for i=1:length(theta)
        d(i) = 1/no_examples*sum(err.*X(:,i));
    end
end