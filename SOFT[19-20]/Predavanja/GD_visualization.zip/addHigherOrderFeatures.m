% podrazumeva vektor-kolonu x -> samo jedno obelezje cije stepene treba da
% doda
% istovremeno prosiruje x sa jedinicama (intercept term)
% p - najvisi stepen obelezja
function X = addHigherOrderFeatures(x, p)
    X = ones(size(x, 1), p+1);
    for i=2:p+1
        X(:,i) = X(:,i-1).*x;
    end
end