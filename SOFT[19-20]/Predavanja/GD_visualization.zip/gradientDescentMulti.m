function [theta, J_history, theta_history, converged_it] = gradientDescentMulti(X, y, theta, alpha, num_iters)
%GRADIENTDESCENTMULTI Performs gradient descent to learn theta
%   theta = GRADIENTDESCENTMULTI(x, y, theta, alpha, num_iters, max_err) updates theta by
%   taking num_iters gradient steps with learning rate alpha. 

max_err = 0.00001;
converged_it = -1; 

J_history = zeros(num_iters+1, 1); % history of cost function (its value in each step)
J_history(1) = computeCostMulti(X, y, theta);

theta_history = zeros(num_iters+1, length(theta)); % history of parameter values (parameter values in each step)
theta_history(1, :) = theta; % setting initial value

for iter = 1:num_iters
    d = calcDerrivative(X, y, theta);
    theta = theta - alpha*d;

    theta_history(iter+1, :) = theta;
    J_history(iter+1) = computeCostMulti(X, y, theta);

    % check convergence criteria
    if(converged_it == -1) % ako nije vec detektovana konvergencija
        d_magnitude = sqrt(sum(d.^2));
        if d_magnitude < max_err
            converged_it = iter;            
        end;  
    end

end

end
