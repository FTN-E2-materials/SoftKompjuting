% Iscrtava cost funkciju J i korake za razlicito theta
% Podrazumeva samo 2 theta parametra
function [] = plotGradientDescentSteps3D(theta_history, J_history, X, y, converged_it, alpha)

% otvaramo novi prozor za sliku, maksimizovan
figure('units','normalized','outerposition',[0 0 1 1]);
% U naslovu ispisujemo alpha i formulu za gradient descent
alpha_text = strcat('\alpha = ', num2str(alpha));
formula_text = '\newline\theta_t = \theta_{t-1} - \alphad';
tit = suptitle(strcat(alpha_text, formula_text));
set(tit, 'FontSize', 22);

% Proveravam koliko ima iteracija u gradientDescent do konvergencije. Ako
% je converged_it == -1 to znaci da nije doslo do (automatske) detekcije
% konvergencije (promena J(theta) iz iteracije u iteraciju nije propisano
% mala). U tom slucaju broj koraka gradientDescent jednaka je broju
% iteracija. U suprotnom uzimamo da je broj koraka jednak onom u kome je
% doslo do detekcije konvergencije.
if converged_it ~= -1
    noSteps = converged_it;
else
    noSteps = size(theta_history, 1);
end

% color: marker se menja iz plave u crvenu u noSteps koraka.
color = jet(noSteps); 

% granice za grafik - podeseno isprobavanjem za ovaj primer
start_theta0 = -10; 
end_theta0 = 150;
start_theta1 = -50;
end_theta1 = 50;

%--------------------------------------------------------------------------
% Plotovanje J(theta) u 3D prostoru (ose su theta0 i theta1). 
% subplot(2, 2, [1 3]) - figure je podeljen na 4 subplota (u 2 reda i 2 kolone)
% J(theta) u 3D prostoru prekriva subplotove [1 3], tj proteze se preko
% cele 1. kolone
no_examples = size(X, 1);
xx = linspace(start_theta0, end_theta0, 100); % xx uzima sve moguce vrednosti za theta0
yy = linspace(start_theta1, end_theta1, 100); % yy uzima sve moguce vrednosti za theta1
[xx yy] = meshgrid(xx,yy);
J = zeros(size(xx));
for i=1:size(xx,1)
    for j=1:size(xx,2)       
        J(i,j) = 1/(2*no_examples)*sum((X*[xx(i,j); yy(i,j)] - y).^2); % za svaku kombinaciju xx, yy (theta0, theta1) racunamo J(theta)
    end
end
subplot(2, 2, [1 3]), surf(xx, yy, J, 'EdgeColor', 'none', 'FaceAlpha', 0.3); hold on;
xlabel('\theta_0', 'FontSize',16);
ylabel('\theta_1', 'FontSize', 16);
zlabel('J(\theta)', 'FontSize', 16);
%--------------------------------------------------------------------------
% Plotovanje J(theta) kao contour plot (dole desno - subplot 4)
subplot(2, 2, 4), contour(xx, yy, J, 20); hold on;
%--------------------------------------------------------------------------
% Za sve grafike plotujemo inicijalnu vrednost (pocetno theta)
init_theta = theta_history(1, :)';
init_J = J_history(1);
init_d = calcDerrivative(X, y, init_theta);
init_color = color(1, :);

    %-------- J(theta) u 3D prostoru    
    subplot(2, 2, [1 3]), plot3(init_theta(1), init_theta(2) , init_J, '-o', 'MarkerSize', 10, 'MarkerFaceColor', init_color);   
    derrivativeTxt = strcat('d = [', num2str(init_d(1), '%.2f'), ', ', num2str(init_d(2), '%.2f'), ']');
    title(derrivativeTxt, 'FontSize', 20);
    %-------- J(theta) contour plot (dole desno, subplot 4)
    subplot(2, 2, 4), plot(init_theta(1), init_theta(2), 'o', 'MarkerSize', 10, 'MarkerFaceColor', init_color);
    %-------- Inicijalni model (gore desno, subplot 2)
    subplot(2, 2, 2); plotTheModel2D(X(:,2), y, init_theta, 6, 0.5, [], []); % X(:, 2) - u 2. koloni je feature x
    % Napomena: za init_theta=[0 0] ne vidi se jer se radi o tacki
%--------------------------------------------------------------------------    

%---- Iscrtavanje grafika korak po korak sa promenom theta ----------------
for i=2:noSteps    
    pause % nastavlja dalje tek nakon enter
    
    % ovaj korak:
    theta = theta_history(i, :)';
    J = computeCostMulti(X, y , theta); 
    
    % prethodni korak:
    theta_prev_step = theta_history(i-1, :)';    
    J_prev_step = computeCostMulti(X, y , theta_prev_step);
    
    %-------- J(theta) u 3D prostoru ----------
    subplot(2, 2, [1 3]);
    % pozicija theta:
    plot3(theta(1), theta(2), J, 'o', 'MarkerSize', 10, 'MarkerFaceColor', color(i, :));  
    % linija iz prethodnog u ovaj korak:
    subplot(2, 2, [1 3]), plot3([theta_prev_step(1), theta(1)], [theta_prev_step(2), theta(2)], [J_prev_step, J]); 
    % ispis nove vrednosti gradijenta:
    d = calcDerrivative(X, y, theta_history(i, :)');
    derrivativeTxt = strcat('d = [', num2str(d(1), '%.2f'), ', ', num2str(d(2), '%.2f'), ']');
    title(derrivativeTxt, 'FontSize', 20);
    
    %-------- J(theta) contour plot ----------    
    subplot(2, 2, 4);
    plot(theta(1), theta(2), 'o', 'MarkerSize', 10, 'MarkerFaceColor', color(i, :)); 
    
    %-------- Iscrtavanje modela ----------
    subplot(2, 2, 2); 
    plotTheModel2D(X(:,2), y, theta, 6, 0.5, [], []); % X(:, 2) - u 2. koloni je feature x
end
hold off;
