% Plot the convergence graph (cost function in each step)
function [] = plotTheConvergenceGraph(J_history)
figure;
plot(1:numel(J_history), J_history, '-b', 'LineWidth', 2);
xlabel('Number of iterations', 'FontSize',16);
ylabel('Cost J', 'FontSize', 16);
end