# import libraries here


def count_blood_cells(image_path):
    """
    Procedura prima putanju do fotografije i vraca broj krvnih zrnaca.

    Ova procedura se poziva automatski iz main procedure i taj deo kod nije potrebno menjati niti implementirati.

    :param image_path: <String> Putanja do ulazne fotografije.
    :return: <int>  Broj prebrojanih krvnih zrnaca
    """
    blood_cell_count = 0
    # TODO - Prebrojati krvna zrnca i vratiti njihov broj kao povratnu vrednost ove procedure

    return blood_cell_count
